def update(x,sigma,dt):
    return 1
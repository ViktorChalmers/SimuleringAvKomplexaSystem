from tqdm import tqdm,trange
import time

for i in tqdm(range(10)):
    time.sleep(0.3)